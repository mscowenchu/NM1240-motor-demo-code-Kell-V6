
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'NM1240_1R_2R_6stp_Hall_FOC' 
 * Target:  'NM1230_1R_2R_6stp_Hall_FOC' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "NM1240Series.h"



#endif /* RTE_COMPONENTS_H */
